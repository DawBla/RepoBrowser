package com.dawidblaszyk.repobrowser

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.dawidblaszyk.repobrowser.dto.GithubOwnerX
import com.dawidblaszyk.repobrowser.dto.GithubRepoJSONItem

class RecyclerAdapter(
    val context: Context,
    val githubItems: List<GithubRepoJSONItem>,
    val githubOwner: List<GithubOwnerX>
): RecyclerView.Adapter<RecyclerAdapter.ViewHolder>() {

    class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        var repoName: TextView
        var repoOwner: TextView

        init {
            repoName = itemView.findViewById(R.id.entry_repo_name)
            repoOwner = itemView.findViewById(R.id.entry_repo_owner)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        var itemView = LayoutInflater.from(context).inflate(R.layout.list_entry, parent, false)
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.repoName.text = githubItems[position].name.toString()
        holder.repoOwner.text = githubOwner[position].login.toString()
    }

    override fun getItemCount(): Int {
        return githubItems.size
    }
}