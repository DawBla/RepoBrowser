package com.dawidblaszyk.repobrowser.dto

class GithubRepoJSON : ArrayList<GithubRepoJSONItem>()